import './styles/main.css';

import { state, isAdmin }                       from './lib/store.js';
import { loadAll, runScan, IS_DEMO, signOut }   from './lib/data.js';
import { getSession, getMemberByAuthId }         from './lib/data.js';
import { toast, closeModal, showModal, initials, avColor, fmtDate, fmtTime, pwStrength, togglePw, APP_DOMAIN, validateDudaEmail } from './lib/utils.js';

import { renderLogin, attachLoginHandlers }      from './pages/login.js';
import { renderDashboard }                       from './pages/dashboard.js';
import { renderClients, openAddClientModal, openEditClientModal, handleDeleteClient, handleSetFlow } from './pages/clients.js';
import { renderScans, renderScanReport }         from './pages/scans.js';
import { renderTeam, openInviteModal, openEditMemberModal, openRoleGuide, setInviteRole, setEditRole, handleChangeRole, handleSuspendMember, handleReactivateMember, handleRemoveMember } from './pages/team.js';
import { renderSettings, handleClearScans, handleExportData } from './pages/settings.js';
import { renderAbout } from './pages/about.js';
import { iGrid, iGlobe, iActivity, iUsers, iSettings, iSearch, iPlus, iLock, iEye, iInfo, iBook } from './lib/icons.js';

// ── Page meta ─────────────────────────────────────────────────
const PAGE_META = {
  dashboard: { title: 'Dashboard',        sub: 'Your site monitoring overview' },
  clients:   { title: 'Clients & Sites',  sub: 'All monitored websites' },
  scans:     { title: 'Scan History',     sub: 'AI-generated site reports' },
  team:      { title: 'Team Management',  sub: `Members, roles & invitations — @${APP_DOMAIN} only` },
  settings:  { title: 'Settings',         sub: 'Scanner configuration and preferences' },
  about:     { title: 'About',            sub: 'Tool capabilities and setup guide' },
};

// ── Expose globals needed by inline handlers ──────────────────
window._closeModal      = closeModal;
window._pwStrength      = pwStrength;
window._togglePw        = togglePw;
window._reloadAndRender = reloadAndRender;

// ── Boot ──────────────────────────────────────────────────────
(async () => {
  const session = await getSession();
  if (!session) {
    renderLoginView();
    return;
  }
  const member = await getMemberByAuthId(session.user.id);
  if (!member || member.status === 'suspended') {
    renderLoginView(); return;
  }
  state.session = session;
  state.member  = member;
  await reloadAndRender('dashboard');
})();

// ── Login view ────────────────────────────────────────────────
function renderLoginView() {
  document.getElementById('app').innerHTML = renderLogin();
  attachLoginHandlers(async () => {
    await reloadAndRender('dashboard');
    toast(`Welcome back, ${state.member.name.split(' ')[0]}!`, 'success');
  });
}

// ── Reload data + render a page ───────────────────────────────
async function reloadAndRender(page) {
  state.page = page || state.page;
  const { members, clients, scans } = await loadAll();
  state.members = members;
  state.clients = clients;
  state.scans   = scans;
  renderShell();
  renderPageContent();
}

// ── Shell (sidebar + topbar skeleton) ────────────────────────
function renderShell() {
  const due  = state.clients.filter(c => {
    const last = c.last_scan;
    return !last || Date.now() > new Date(last).getTime() + 21 * 86400000;
  });

  const navItems = [
    { id: 'dashboard', label: 'Dashboard',       icon: iGrid },
    { id: 'clients',   label: 'Clients & Sites', icon: iGlobe,    badge: due.length },
    { id: 'scans',     label: 'Scan History',    icon: iActivity },
  ];
  if (isAdmin()) {
    navItems.push({ id: 'team',     label: 'Team',     icon: iUsers });
    navItems.push({ id: 'settings', label: 'Settings', icon: iSettings });
  }
  const bottomNavItems = [
    { id: 'about', label: 'About this tool', icon: iBook },
  ];

  document.getElementById('app').innerHTML = `
  ${IS_DEMO ? `<div class="demo-banner">
    🔬 Demo mode — using mock data. Add Supabase keys to <code>.env</code> to go live.
    See <a href="#" onclick="window._nav('settings');return false">Settings</a> for details.
  </div>` : ''}
  <div class="app">
    <div class="sidebar">
      <div class="sb-logo">
        <div class="sb-eyebrow">Duda</div>
        <div class="sb-title">Site Scanner <span class="sb-pill">AM</span></div>
      </div>
      <nav class="sb-nav">
        <div class="sb-section">Navigation</div>
        ${navItems.map(n => `
        <div class="nav-item ${state.page === n.id ? 'active' : ''}" data-nav="${n.id}">
          ${n.icon} ${n.label}
          ${n.badge ? `<span class="nav-badge">${n.badge}</span>` : ''}
        </div>`).join('')}
        <div style="height:1px;background:rgba(255,255,255,.07);margin:10px 2px"></div>
        ${bottomNavItems.map(n => `
        <div class="nav-item ${state.page === n.id ? 'active' : ''}" data-nav="${n.id}" style="color:rgba(255,255,255,.3)">
          ${n.icon} ${n.label}
        </div>`).join('')}
      </nav>
      <div class="sb-foot">
        <div class="sb-user" data-action="openProfileModal">
          <div class="av av-32 ${avColor(state.member?.role)}">${initials(state.member?.name || '?')}</div>
          <div>
            <div class="sb-uname">${state.member?.name || '…'}</div>
            <div class="sb-urole">${state.member?.role === 'admin' ? 'Admin' : 'Staff'} · Duda</div>
          </div>
        </div>
      </div>
    </div>
    <div class="main">
      <div class="topbar">
        <div>
          <div class="tb-title" id="tb-title"></div>
          <div class="tb-sub"   id="tb-sub"></div>
        </div>
        <div class="tb-actions" id="tb-actions"></div>
      </div>
      <div class="content fadein" id="content"></div>
    </div>
  </div>`;

  attachDelegation();
}

// ── Render page content ───────────────────────────────────────
function renderPageContent(subView) {
  const meta = PAGE_META[state.page] || PAGE_META.dashboard;
  const tb = document.getElementById('tb-title');
  const ts = document.getElementById('tb-sub');
  const ta = document.getElementById('tb-actions');
  if (tb) tb.textContent = meta.title;
  if (ts) ts.textContent = meta.sub;

  // Topbar actions per page
  const actions = {
    dashboard: `<button class="btn btn-primary btn-sm" data-action="openScanPicker">${iSearch} Run scan</button>`,
    clients:   `<button class="btn btn-primary btn-sm" data-action="openAddClientModal">${iPlus} Add client</button>`,
    scans:     `<button class="btn btn-primary btn-sm" data-action="openScanPicker">${iSearch} Run scan</button>`,
    team:      isAdmin() ? `
      <button class="btn btn-secondary btn-sm" data-action="openRoleGuide">Role guide</button>
      <button class="btn btn-primary btn-sm"   data-action="openInviteModal">${iPlus} Invite</button>` : '',
    settings:  '',
  };
  if (ta) ta.innerHTML = actions[state.page] || '';

  // Page content
  const c = document.getElementById('content');
  if (!c) return;
  c.className = 'content fadein';

  if (subView?.type === 'scanReport') {
    c.innerHTML = renderScanReport(subView.id);
    return;
  }

  const renderers = {
    dashboard: renderDashboard,
    clients:   renderClients,
    scans:     renderScans,
    team:      renderTeam,
    settings:  renderSettings,
    about:     renderAbout,
  };
  c.innerHTML = (renderers[state.page] || renderDashboard)();
}

// ── Event delegation ──────────────────────────────────────────
function attachDelegation() {
  document.getElementById('app').addEventListener('click', handleClick);
}

async function handleClick(e) {
  // Nav items
  const navEl = e.target.closest('[data-nav]');
  if (navEl) { await reloadAndRender(navEl.dataset.nav); return; }

  // Action buttons
  const el = e.target.closest('[data-action]');
  if (!el) return;

  const action = el.dataset.action;
  const id     = el.dataset.id;
  const role   = el.dataset.role;

  switch (action) {

    // ── Navigation ─────────────────────────────────────────
    case 'viewScan':
      state.page = 'scans';
      renderPageContent({ type: 'scanReport', id });
      break;

    // ── Scan ───────────────────────────────────────────────
    case 'openScanPicker': openScanPicker(); break;
    case 'runScan': await doRunScan(id); break;

    // ── Clients ────────────────────────────────────────────
    case 'openAddClientModal': openAddClientModal(); break;
    case 'openEditClientModal': openEditClientModal(id); break;
    case 'deleteClient': await handleDeleteClient(id); break;
    case 'setFlow': handleSetFlow(el.dataset.prefix, el.dataset.flow); break;

    // ── Team ───────────────────────────────────────────────
    case 'openInviteModal':    openInviteModal(); break;
    case 'openEditMemberModal': openEditMemberModal(id); break;
    case 'openRoleGuide':      openRoleGuide(); break;
    case 'setInvRole':         setInviteRole(role); break;
    case 'setEditRole':        setEditRole(role); break;
    case 'changeRole':         await handleChangeRole(id, role); break;
    case 'suspendMember':      await handleSuspendMember(id); break;
    case 'reactivateMember':   await handleReactivateMember(id); break;
    case 'removeMember':       await handleRemoveMember(id); break;

    // ── Settings ───────────────────────────────────────────
    case 'clearScans':  await handleClearScans(); break;
    case 'exportData':  handleExportData(); break;

    // ── Profile ────────────────────────────────────────────
    case 'openProfileModal': openProfileModal(); break;
  }
}

// Expose nav for demo banner link
window._nav = (page) => reloadAndRender(page);

// ── Scan picker modal ─────────────────────────────────────────
function openScanPicker() {
  const myClients = isAdmin()
    ? state.clients
    : state.clients.filter(c => c.am_id === state.member.id);

  if (!myClients.length) {
    toast('Add a client first', 'danger');
    reloadAndRender('clients');
    return;
  }

  const opts = myClients.map(c => {
    const due = !c.last_scan || Date.now() > new Date(c.last_scan).getTime() + 21*86400000;
    return `<option value="${c.id}">${c.name}${due ? ' ⚠ due' : ''} — ${c.url.replace(/^https?:\/\//,'').slice(0,36)}</option>`;
  }).join('');

  showModal(`<div class="modal">
    <div class="modal-hd">
      <div class="modal-title">Run AI site scan</div>
      <button class="modal-x" onclick="window._closeModal()">×</button>
    </div>
    <div class="modal-body">
      <div class="fg">
        <label class="flabel">Select client</label>
        <select class="fselect" id="sp-client">${opts}</select>
      </div>
      ${IS_DEMO ? `
      <div class="alert alert-warn" style="margin-top:8px">
        ${iInfo}
        <span><strong>Demo mode:</strong> Returns realistic mock scan data instantly. Connect Supabase + Anthropic key for live AI scans.</span>
      </div>` : `
      <div class="alert alert-info" style="margin-top:8px">
        ${iInfo}
        <span>AI will visit the live site, detect changes and new content, and generate improvement recommendations.</span>
      </div>`}
    </div>
    <div class="modal-foot">
      <button class="btn btn-secondary" onclick="window._closeModal()">Cancel</button>
      <button class="btn btn-primary" id="sp-go-btn">${iSearch} Start scan</button>
    </div>
  </div>`);

  document.getElementById('sp-go-btn').addEventListener('click', () => {
    const id = document.getElementById('sp-client')?.value;
    closeModal();
    if (id) doRunScan(id);
  });
}

// ── Run scan ──────────────────────────────────────────────────
async function doRunScan(clientId) {
  const client = state.clients.find(c => c.id === clientId);
  state.page = 'scans';
  renderShell();

  const c = document.getElementById('content');
  if (c) c.innerHTML = `
    <div class="card" style="max-width:480px;margin:40px auto">
      <div class="card-body" style="padding:40px;text-align:center">
        <div class="spinner" style="margin:0 auto 18px"></div>
        <div style="font-weight:600;font-size:15px;margin-bottom:6px">Scanning ${client?.name || 'site'}…</div>
        <div style="color:var(--text2);font-size:12px;margin-bottom:16px">
          ${IS_DEMO ? 'Generating demo scan report…' : `AI is visiting <span class="mono">${client?.url}</span>`}
        </div>
        <div class="prog-bar"><div class="prog-fill pulsing" style="width:70%"></div></div>
        <div style="color:var(--text3);font-size:11px;margin-top:10px">
          ${IS_DEMO ? 'Just a moment…' : 'Usually takes 15–30 seconds'}
        </div>
      </div>
    </div>`;

  const { data, error } = await runScan(clientId);

  if (error) {
    const c2 = document.getElementById('content');
    if (c2) c2.innerHTML = `
      <div class="card" style="max-width:440px;margin:40px auto">
        <div class="card-body" style="padding:40px;text-align:center">
          <div style="font-size:32px;margin-bottom:12px">⚠</div>
          <div style="font-weight:600;margin-bottom:8px">Scan failed</div>
          <div style="color:var(--text2);font-size:12px;margin-bottom:18px">${error.message}</div>
          <button class="btn btn-primary btn-sm" data-action="runScan" data-id="${clientId}">Try again</button>
        </div>
      </div>`;
    return;
  }

  const emailMsg = data.email_sent ? ' — report emailed to AM' : '';
  toast(`Scan complete${emailMsg}`, 'success');

  // Reload data then show the report
  const fresh = await loadAll();
  state.members = fresh.members;
  state.clients = fresh.clients;
  state.scans   = fresh.scans;
  renderShell();
  renderPageContent({ type: 'scanReport', id: data.scan_id });
}

// ── Profile modal ─────────────────────────────────────────────
function openProfileModal() {
  const m = state.member;
  showModal(`<div class="modal">
    <div class="modal-hd">
      <div class="modal-title">My profile</div>
      <button class="modal-x" onclick="window._closeModal()">×</button>
    </div>
    <div class="modal-body">
      <div style="display:flex;align-items:center;gap:14px;margin-bottom:18px;padding-bottom:16px;border-bottom:1px solid var(--border)">
        <div class="av av-32 ${avColor(m.role)}" style="width:48px;height:48px;font-size:16px">${initials(m.name)}</div>
        <div>
          <div style="font-weight:600;font-size:15px">${m.name}</div>
          <div style="font-size:12px;color:var(--text2)">${m.email}</div>
          <span class="badge ${m.role === 'admin' ? 'badge-blue' : 'badge-green'}" style="margin-top:5px">${m.role}</span>
        </div>
      </div>
      <div class="fg">
        <label class="flabel">Display name</label>
        <input class="finput" id="pr-name" value="${m.name}">
      </div>
      ${!IS_DEMO ? `
      <div class="fg" style="margin-bottom:0">
        <label class="flabel">New password <span style="font-weight:400;color:var(--text3)">(leave blank to keep)</span></label>
        <div class="pw-wrap">
          <input class="finput" id="pr-pw" type="password" placeholder="Min 8 characters"
            oninput="window._pwStrength('pr-pw','pr-pw-bar')">
          <button class="pw-toggle" type="button" onclick="window._togglePw('pr-pw')">${iEye}</button>
        </div>
        <div class="pw-strength" id="pr-pw-bar"></div>
      </div>` : `
      <div class="alert alert-info" style="margin-top:4px">
        ${iInfo}<span>Password changes are disabled in demo mode.</span>
      </div>`}
    </div>
    <div class="modal-foot">
      <button class="btn btn-danger btn-sm" id="pr-logout-btn" style="margin-right:auto">Sign out</button>
      <button class="btn btn-secondary" onclick="window._closeModal()">Cancel</button>
      <button class="btn btn-primary" id="pr-save-btn">Save</button>
    </div>
  </div>`);

  document.getElementById('pr-logout-btn').addEventListener('click', async () => {
    await signOut();
    state.session = null;
    state.member  = null;
    closeModal();
    renderLoginView();
  });

  document.getElementById('pr-save-btn').addEventListener('click', async () => {
    const name = document.getElementById('pr-name').value.trim();
    if (name && name !== m.name) {
      const { updateMember } = await import('./lib/data.js');
      await updateMember(m.id, { name });
      state.member = { ...state.member, name };
    }
    if (!IS_DEMO) {
      const pw = document.getElementById('pr-pw')?.value;
      if (pw && pw.length >= 8) {
        const { sb } = await import('./lib/data.js');
        await sb?.auth.updateUser({ password: pw });
      }
    }
    closeModal();
    await reloadAndRender(state.page);
    toast('Profile updated');
  });
}
