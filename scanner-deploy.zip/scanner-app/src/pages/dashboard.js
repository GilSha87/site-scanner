import { state, isAdmin } from '../lib/store.js';
import { isDue, nextScanStr, fmtDate, fmtTime, scoreColor, initials, avColor } from '../lib/utils.js';
import { iGrid, iActivity, iGlobe, iSearch, iInfo } from '../lib/icons.js';

const iAlert = `<svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke-width="2"/><line x1="12" y1="9" x2="12" y2="13" stroke-width="2"/><line x1="12" y1="17" x2="12.01" y2="17" stroke-width="3"/></svg>`;
const iTrend = `<svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18" stroke-width="2"/><polyline points="17 6 23 6 23 12" stroke-width="2"/></svg>`;

export function renderDashboard() {
  const myClients = isAdmin() ? state.clients : state.clients.filter(c => c.am_id === state.member.id);
  const due       = myClients.filter(c => isDue(c.last_scan));
  const myScans   = state.scans.filter(s => myClients.find(c => c.id === s.client_id));
  const recent    = myScans.slice(0, 6);

  const allRedFlags  = myScans.flatMap(s => (s.result?.redFlags || []).map(f => ({ ...f, scan: s })));
  const allGrowth    = myScans.flatMap(s => (s.result?.growthSignals || []).map(g => ({ ...g, scan: s })));
  const criticalFlags = allRedFlags.filter(f => f.severity === 'critical');
  const warnFlags     = allRedFlags.filter(f => f.severity === 'warn');

  const typeLabel = t => ({ tier_shifting:'Tier shift', vertical_expansion:'New vertical', content_velocity:'Content growth', ai_adoption:'AI adoption', competitor_detected:'Competitor detected', page_404:'Page 404', lead_form_broken:'Form broken', ssl_expiry:'SSL expiry', duda_removed:'Duda removed' }[t] || t);

  const riskBadge = risk => risk === 'critical'
    ? '<span class="badge badge-red"><span class="dot"></span>Critical</span>'
    : risk === 'warn'
    ? '<span class="badge badge-amber"><span class="dot"></span>Warning</span>'
    : '<span class="badge badge-green"><span class="dot"></span>Clear</span>';

  return `
  <div class="stat-grid stat-grid-4">
    <div class="stat-card">
      <div class="stat-lbl">${isAdmin() ? 'All clients' : 'My clients'}</div>
      <div class="stat-val">${myClients.length}</div>
      <div class="stat-sub">Monitored sites</div>
    </div>
    <div class="stat-card">
      <div class="stat-lbl">Due for scan</div>
      <div class="stat-val" style="color:${due.length > 0 ? 'var(--warn)' : 'var(--success)'}">${due.length}</div>
      <div class="stat-sub">${due.length > 0 ? 'Overdue or never scanned' : 'All up to date'}</div>
    </div>
    <div class="stat-card">
      <div class="stat-lbl">Critical flags</div>
      <div class="stat-val" style="color:${criticalFlags.length > 0 ? 'var(--danger)' : 'var(--success)'}">${criticalFlags.length}</div>
      <div class="stat-sub">${criticalFlags.length > 0 ? 'Need immediate action' : 'All clear'}</div>
    </div>
    <div class="stat-card">
      <div class="stat-lbl">Growth signals</div>
      <div class="stat-val" style="color:${allGrowth.length > 0 ? 'var(--brand)' : 'var(--text3)'}">${allGrowth.length}</div>
      <div class="stat-sub">${allGrowth.length > 0 ? 'Expansion opportunities' : 'None this cycle'}</div>
    </div>
  </div>

  ${due.length > 0 ? `
  <div class="alert alert-warn" style="margin-bottom:14px">
    ${iInfo}<span><strong>${due.length} site${due.length > 1 ? 's' : ''}</strong> due for scanning: ${due.map(c => c.name).join(', ')}</span>
  </div>` : ''}

  ${criticalFlags.length > 0 ? `
  <div style="background:var(--danger-bg);border:1px solid var(--danger-border);border-radius:var(--rl);padding:16px 18px;margin-bottom:14px">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
      <span style="color:var(--danger)">${iAlert}</span>
      <span style="font-size:12px;font-weight:600;color:var(--danger)">${criticalFlags.length} critical flag${criticalFlags.length > 1 ? 's' : ''} — immediate action required</span>
    </div>
    ${criticalFlags.slice(0, 3).map(f => {
      const client = state.clients.find(c => c.id === f.scan?.client_id);
      return `<div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px;padding:10px 12px;background:rgba(220,38,38,.06);border-radius:var(--r);border-left:3px solid var(--danger)">
        <div style="flex:1;min-width:0">
          <div style="font-size:11px;font-weight:700;color:var(--danger);margin-bottom:2px;text-transform:uppercase;letter-spacing:.4px">${typeLabel(f.type)} · ${client?.name || 'Unknown'}</div>
          <div style="font-size:12px;font-weight:600;color:var(--text);margin-bottom:3px">${f.title}</div>
          <div style="font-size:11px;color:var(--text2);line-height:1.5">${f.csmInsight}</div>
        </div>
        <button class="btn btn-danger btn-xs" data-action="viewScan" data-id="${f.scan?.id}" style="flex-shrink:0">View →</button>
      </div>`;
    }).join('')}
    ${criticalFlags.length > 3 ? `<div style="font-size:11px;color:var(--danger);margin-top:4px">+ ${criticalFlags.length - 3} more critical flag${criticalFlags.length - 3 > 1 ? 's' : ''} — check scan history</div>` : ''}
  </div>` : ''}

  ${warnFlags.length > 0 && criticalFlags.length === 0 ? `
  <div style="background:var(--warn-bg);border:1px solid var(--warn-border);border-radius:var(--rl);padding:14px 18px;margin-bottom:14px">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
      ${iInfo}
      <span style="font-size:12px;font-weight:600;color:var(--warn)">${warnFlags.length} warning${warnFlags.length > 1 ? 's' : ''} detected across your clients</span>
    </div>
    ${warnFlags.slice(0,2).map(f => {
      const client = state.clients.find(c => c.id === f.scan?.client_id);
      return `<div style="font-size:11px;color:var(--warn);margin-bottom:4px;display:flex;gap:6px"><span>⚠</span><span><strong>${client?.name}:</strong> ${f.title}</span></div>`;
    }).join('')}
  </div>` : ''}

  ${allGrowth.length > 0 ? `
  <div style="background:var(--brand-light);border:1px solid var(--brand-mid);border-radius:var(--rl);padding:16px 18px;margin-bottom:14px">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
      <span style="color:var(--brand)">${iTrend}</span>
      <span style="font-size:12px;font-weight:600;color:var(--brand)">${allGrowth.length} growth signal${allGrowth.length > 1 ? 's' : ''} — expansion opportunities detected</span>
    </div>
    ${allGrowth.slice(0, 3).map(g => {
      const client = state.clients.find(c => c.id === g.scan?.client_id);
      return `<div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px;padding:10px 12px;background:rgba(29,78,216,.06);border-radius:var(--r);border-left:3px solid var(--brand)">
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
            <span style="font-size:9px;font-weight:700;background:var(--brand);color:#fff;padding:1px 6px;border-radius:10px;text-transform:uppercase;letter-spacing:.4px">${typeLabel(g.type)}</span>
            <span style="font-size:11px;font-weight:600;color:var(--brand)">${client?.name || 'Unknown'}</span>
          </div>
          <div style="font-size:12px;font-weight:600;color:var(--text);margin-bottom:2px">${g.title}</div>
          <div style="font-size:11px;color:var(--text2);line-height:1.5">${g.csmInsight}</div>
        </div>
        <button class="btn btn-ghost btn-xs" data-action="viewScan" data-id="${g.scan?.id}" style="flex-shrink:0">View →</button>
      </div>`;
    }).join('')}
    ${allGrowth.length > 3 ? `<div style="font-size:11px;color:var(--brand);margin-top:4px">+ ${allGrowth.length - 3} more growth signal${allGrowth.length - 3 > 1 ? 's' : ''} in scan history</div>` : ''}
  </div>` : ''}

  <div class="card" style="margin-bottom:16px">
    <div class="card-hd">
      <div class="card-title">${iActivity} Recent scans</div>
      <button class="btn btn-ghost btn-xs" data-nav="scans">View all →</button>
    </div>
    ${recent.length === 0 ? `
    <div class="empty">
      <div class="empty-icon">${iSearch}</div>
      <div class="empty-title">No scans yet</div>
      <div class="empty-sub">Add a client and run your first AI scan</div>
      <button class="btn btn-primary btn-sm" data-action="openScanPicker">Run first scan</button>
    </div>` : `
    <div class="tbl-wrap"><table>
      <thead><tr><th>Client</th><th>Scanned</th><th>Risk</th><th>Red flags</th><th>Growth signals</th><th>Score</th><th></th></tr></thead>
      <tbody>
        ${recent.map(scan => {
          const client = state.clients.find(c => c.id === scan.client_id);
          const risk   = scan.result?.riskLevel || 'ok';
          const flags  = scan.result?.redFlags?.length || 0;
          const growth = scan.result?.growthSignals?.length || 0;
          const sc     = scan.result?.score || '—';
          return `<tr>
            <td>
              <div style="font-weight:600">${client?.name || 'Unknown'}</div>
              <div class="mono" style="color:var(--text3)">${(client?.url || '').replace(/^https?:\/\//, '').slice(0, 28)}</div>
            </td>
            <td style="color:var(--text2);font-size:11px">${fmtDate(scan.created_at)}</td>
            <td>${riskBadge(risk)}</td>
            <td>${flags > 0 ? `<span class="badge badge-red">${flags}</span>` : '<span class="badge badge-gray">0</span>'}</td>
            <td>${growth > 0 ? `<span class="badge badge-blue">${growth}</span>` : '<span class="badge badge-gray">0</span>'}</td>
            <td><strong style="color:${scoreColor(sc)}">${sc}/10</strong></td>
            <td><button class="btn btn-ghost btn-xs" data-action="viewScan" data-id="${scan.id}">View →</button></td>
          </tr>`;
        }).join('')}
      </tbody>
    </table></div>`}
  </div>

  ${myClients.length > 0 ? `
  <div class="card">
    <div class="card-hd"><div class="card-title">${iGlobe} Site status</div></div>
    <div class="tbl-wrap"><table>
      <thead><tr><th>Client</th><th>Last scan</th><th>Next scan</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${myClients.map(c => `<tr>
          <td>
            <div style="font-weight:600">${c.name}</div>
            <div class="mono" style="color:var(--text3)">${c.url.replace(/^https?:\/\//, '').slice(0, 32)}</div>
          </td>
          <td style="color:var(--text2)">${c.last_scan ? fmtDate(c.last_scan) : '—'}</td>
          <td style="color:var(--text2);font-size:11px">${nextScanStr(c.last_scan)}</td>
          <td>${isDue(c.last_scan) ? '<span class="badge badge-amber"><span class="dot"></span>Due</span>' : '<span class="badge badge-green"><span class="dot"></span>OK</span>'}</td>
          <td><button class="btn btn-ghost btn-xs" data-action="runScan" data-id="${c.id}">Scan now</button></td>
        </tr>`).join('')}
      </tbody>
    </table></div>
  </div>` : ''}`;
}
