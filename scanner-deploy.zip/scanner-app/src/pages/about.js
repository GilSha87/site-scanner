import { IS_DEMO } from '../lib/data.js';
import { iSearch, iUsers, iGlobe, iActivity, iCheck, iLock, iInfo, iSettings } from '../lib/icons.js';

export function renderAbout() {
  return `
  <div style="max-width:860px">

    <!-- Hero -->
    <div style="background:var(--sidebar);border-radius:var(--rl);padding:32px 36px;margin-bottom:24px;position:relative;overflow:hidden">
      <div style="position:absolute;top:-40px;right:-40px;width:220px;height:220px;border-radius:50%;background:rgba(29,78,216,.15)"></div>
      <div style="position:absolute;bottom:-60px;right:60px;width:140px;height:140px;border-radius:50%;background:rgba(29,78,216,.08)"></div>
      <div style="position:relative">
        <div style="font-size:10px;font-weight:600;color:rgba(255,255,255,.35);letter-spacing:2px;text-transform:uppercase;margin-bottom:10px">Duda · Internal Tool</div>
        <h1 style="font-size:26px;font-weight:600;color:#fff;margin-bottom:8px;line-height:1.2">Duda Site Scanner</h1>
        <p style="font-size:13px;color:rgba(255,255,255,.6);line-height:1.7;max-width:540px;margin-bottom:20px">
          An AI-powered intelligence tool for the Duda AM team. Automatically monitors client websites, detects changes to their offering, and generates strategic insights so every client call is informed, not reactive.
        </p>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <div style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:var(--r);padding:7px 13px;font-size:11px;font-weight:500;color:rgba(255,255,255,.7);display:flex;align-items:center;gap:6px">
            <span style="width:6px;height:6px;border-radius:50%;background:#4ADE80;display:inline-block"></span>
            ${IS_DEMO ? 'Demo mode — UI preview' : 'Live — connected to Supabase'}
          </div>
          <div style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:var(--r);padding:7px 13px;font-size:11px;font-weight:500;color:rgba(255,255,255,.7)">
            Scans every 21 days
          </div>
          <div style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:var(--r);padding:7px 13px;font-size:11px;font-weight:500;color:rgba(255,255,255,.7)">
            @duda.co only
          </div>
        </div>
      </div>
    </div>

    <!-- What it does -->
    <div style="margin-bottom:24px">
      <div style="font-size:10px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:.8px;margin-bottom:14px">What this tool does</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">

        <div class="card" style="padding:18px 20px">
          <div style="width:34px;height:34px;background:var(--brand-light);border-radius:var(--r);display:flex;align-items:center;justify-content:center;margin-bottom:12px;color:var(--brand)">${iSearch}</div>
          <div style="font-size:13px;font-weight:600;margin-bottom:6px">Automated site scanning</div>
          <div style="font-size:12px;color:var(--text2);line-height:1.6">Visits each client site on a 21-day cycle using AI + live web search. No manual work — scans run in the background and results land in the dashboard.</div>
        </div>

        <div class="card" style="padding:18px 20px">
          <div style="width:34px;height:34px;background:var(--warn-bg);border-radius:var(--r);display:flex;align-items:center;justify-content:center;margin-bottom:12px;color:var(--warn)">${iActivity}</div>
          <div style="font-size:13px;font-weight:600;margin-bottom:6px">Offering change detection</div>
          <div style="font-size:12px;color:var(--text2);line-height:1.6">Detects changes to services pages, pricing, portfolio, and homepage CTAs since the last scan. You'll know when a client launches something new before they even tell you.</div>
        </div>

        <div class="card" style="padding:18px 20px">
          <div style="width:34px;height:34px;background:var(--success-bg);border-radius:var(--r);display:flex;align-items:center;justify-content:center;margin-bottom:12px;color:var(--success)">${iCheck}</div>
          <div style="font-size:13px;font-weight:600;margin-bottom:6px">AM talking points</div>
          <div style="font-size:12px;color:var(--text2);line-height:1.6">Every scan generates 3 strategic talking points tailored for your next call — framed as Duda-specific opportunities, not generic feedback.</div>
        </div>

      </div>
    </div>

    <!-- Scan report breakdown -->
    <div class="card" style="margin-bottom:24px">
      <div class="card-hd"><div class="card-title">${iActivity} What's inside every scan report</div></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:0">

          ${[
            ['Executive summary',      'A 2–3 sentence assessment of the website as a business tool — how well it converts interest in their offering into enquiries.', 'brand'],
            ['Detected changes',       'Anything that changed on offering pages since the last scan — new services, updated pricing, portfolio additions, homepage edits.', 'warn'],
            ['New content found',      'New service pages, pricing tiers, portfolio pieces, or CTAs added to the site. Surfaced so you can react before the next scheduled call.', 'success'],
            ['Improvement recommendations', 'Specific, Duda-actionable advice tied to business impact. Focused only on services, pricing, portfolio, homepage, and trust signals — nothing generic.', 'brand'],
            ['Score breakdown',        'Six dimensions scored: Services, Pricing, Portfolio, Homepage, CTAs, and Trust Signals. Gives a quick read on where the offering is strong vs. where to focus.', 'info'],
            ['AM talking points',      'Three ready-to-use insights framed as strategic observations — things you can say in a call that position you as a partner, not just a vendor checking in.', 'success'],
            ['Client-facing summary',  'A shareable one-pager you can send directly to the client. Shows headline score, what\'s working, and two quick wins — no technical language.', 'warn'],
            ['Email notification',     'When email is configured, the assigned AM gets a digest automatically after each scan. Includes top changes and recommendations.', 'brand'],
          ].map(([title, desc, color]) => `
          <div style="padding:14px 18px;border-bottom:1px solid var(--border);border-right:1px solid var(--border)">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">
              <span style="width:7px;height:7px;border-radius:50%;background:var(--${color === 'brand' ? 'brand' : color === 'warn' ? 'warn' : color === 'success' ? 'success' : 'info'});flex-shrink:0"></span>
              <div style="font-size:12px;font-weight:600">${title}</div>
            </div>
            <div style="font-size:11px;color:var(--text2);line-height:1.6;padding-left:15px">${desc}</div>
          </div>`).join('')}

        </div>
      </div>
    </div>

    <!-- Two column: Team + Access -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px">

      <div class="card">
        <div class="card-hd"><div class="card-title">${iUsers} Team & access control</div></div>
        <div class="card-body">
          <div style="margin-bottom:16px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
              <span class="badge badge-blue">Admin</span>
              <span style="font-size:12px;font-weight:600">Full control</span>
            </div>
            <ul style="padding-left:16px;font-size:12px;color:var(--text2);line-height:2">
              <li>Invite and remove team members</li>
              <li>Change roles and reset passwords</li>
              <li>View and manage all clients</li>
              <li>Access settings and export data</li>
            </ul>
          </div>
          <div style="border-top:1px solid var(--border);padding-top:14px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
              <span class="badge badge-green">Staff</span>
              <span style="font-size:12px;font-weight:600">AM access</span>
            </div>
            <ul style="padding-left:16px;font-size:12px;color:var(--text2);line-height:2">
              <li>Run scans on any client</li>
              <li>View all client sites and scan history</li>
              <li>Edit and manage own assigned clients</li>
              <li>Add new clients (assigned to self)</li>
            </ul>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-hd"><div class="card-title">${iLock} Security & access rules</div></div>
        <div class="card-body">
          <div style="font-size:12px;color:var(--text2);line-height:1.8;margin-bottom:14px">
            Access is restricted at every layer — not just the UI.
          </div>
          ${[
            ['@duda.co only',         'Sign-up and invitation both enforce the Duda email domain. External addresses are rejected at the database level — not just the frontend.'],
            ['Row-level security',    'Supabase RLS policies ensure Staff can only edit their own clients even if they call the API directly.'],
            ['Admin-only endpoints',  'Inviting members and changing roles routes through a protected Edge Function that verifies admin role server-side.'],
            ['Session persistence',   'Sessions are managed by Supabase Auth. Suspended accounts are blocked at login, not just the UI.'],
          ].map(([title, desc]) => `
          <div style="display:flex;gap:10px;margin-bottom:12px;font-size:12px">
            <span style="color:var(--success);flex-shrink:0;margin-top:2px">${iCheck}</span>
            <div><strong>${title}</strong><br><span style="color:var(--text2)">${desc}</span></div>
          </div>`).join('')}
        </div>
      </div>

    </div>

    <!-- How the scan cycle works -->
    <div class="card" style="margin-bottom:24px">
      <div class="card-hd"><div class="card-title">${iGlobe} How the 21-day scan cycle works</div></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:0;position:relative">
          <!-- connector line -->
          <div style="position:absolute;top:22px;left:10%;right:10%;height:1px;background:var(--border);z-index:0"></div>
          ${[
            ['1', 'Site added',       'AM adds client URL and assigns themselves as the owner'],
            ['2', 'Scheduler queues', 'pg_cron runs daily at 07:00 UTC and queues any site not scanned in 21 days'],
            ['3', 'AI scans live',    'Edge Function calls Claude with web search — visits the actual site'],
            ['4', 'Report saved',     'Results saved to Supabase. Score, changes, improvements all stored'],
            ['5', 'AM notified',      'Email sent to assigned AM with digest + link to full report in the dashboard'],
          ].map(([n, title, desc]) => `
          <div style="text-align:center;padding:0 8px;position:relative;z-index:1">
            <div style="width:44px;height:44px;border-radius:50%;background:var(--brand);color:#fff;font-size:14px;font-weight:600;display:flex;align-items:center;justify-content:center;margin:0 auto 10px">${n}</div>
            <div style="font-size:11px;font-weight:600;margin-bottom:4px">${title}</div>
            <div style="font-size:10px;color:var(--text2);line-height:1.5">${desc}</div>
          </div>`).join('')}
        </div>
      </div>
    </div>

    <!-- Tech stack -->
    <div class="card" style="margin-bottom:24px">
      <div class="card-hd"><div class="card-title">${iSettings} Technical stack</div></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
          ${[
            ['Frontend',    'Vite + vanilla JS',     'Single-file app. Runs in any browser. No framework dependency.'],
            ['Auth + DB',   'Supabase',               'Postgres with Row Level Security. Auth enforces @duda.co domain at the database trigger level.'],
            ['AI engine',   'Anthropic Claude',       'claude-sonnet-4-20250514 with web_search tool. Visits the live site before generating the report.'],
            ['Scheduler',   'pg_cron',                'Built into Supabase. Queues overdue sites daily. Worker processes up to 5 scans per 30-minute cycle.'],
            ['Email',       'SendGrid',               'Transactional email to the assigned AM after each scan. Optional — app works fully without it.'],
            ['Deploy',      'Vercel + GitHub Actions','Frontend on Vercel CDN. Edge Functions auto-deploy on push to main via GitHub Actions.'],
          ].map(([layer, tech, desc]) => `
          <div style="background:var(--surface2);border-radius:var(--r);padding:13px 14px">
            <div style="font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">${layer}</div>
            <div style="font-size:12px;font-weight:600;margin-bottom:4px">${tech}</div>
            <div style="font-size:11px;color:var(--text2);line-height:1.5">${desc}</div>
          </div>`).join('')}
        </div>
      </div>
    </div>

    <!-- Getting started -->
    <div class="card">
      <div class="card-hd"><div class="card-title">${iCheck} Getting started</div></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <div>
            <div style="font-size:12px;font-weight:600;margin-bottom:10px">Right now (demo mode)</div>
            ${[
              'Log in with any @duda.co email + password <code style="background:var(--surface2);padding:1px 5px;border-radius:4px">demo</code>',
              'Add a client site under Clients & Sites',
              'Run a scan — you\'ll get a full demo report instantly',
              'Invite team members from the Team page',
            ].map(s => `<div style="display:flex;gap:8px;margin-bottom:8px;font-size:12px"><span style="color:var(--success);flex-shrink:0">${iCheck}</span><span>${s}</span></div>`).join('')}
          </div>
          <div>
            <div style="font-size:12px;font-weight:600;margin-bottom:10px">To go live (real data)</div>
            ${[
              'Create a Supabase project and run the SQL migration',
              'Add <code style="background:var(--surface2);padding:1px 5px;border-radius:4px">VITE_SUPABASE_URL</code> and <code style="background:var(--surface2);padding:1px 5px;border-radius:4px">VITE_SUPABASE_ANON_KEY</code> to <code style="background:var(--surface2);padding:1px 5px;border-radius:4px">.env</code>',
              'Set <code style="background:var(--surface2);padding:1px 5px;border-radius:4px">ANTHROPIC_KEY</code> in Supabase secrets and deploy Edge Functions',
              'Deploy frontend to Vercel — done',
            ].map(s => `<div style="display:flex;gap:8px;margin-bottom:8px;font-size:12px"><span style="color:var(--brand);flex-shrink:0">${iCheck}</span><span>${s}</span></div>`).join('')}
          </div>
        </div>
        <div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--border)">
          <div class="alert alert-info" style="margin:0">
            ${iInfo}
            <span>Full setup instructions are in <code>SETUP.md</code> included with the project download. The entire process takes about 45 minutes.</span>
          </div>
        </div>
      </div>
    </div>

    <div style="text-align:center;padding:24px 0 8px;font-size:11px;color:var(--text3)">
      Built for the Duda AM team · Version 1.0
    </div>

  </div>`;
}
