import { state, isAdmin, canEditClient } from '../lib/store.js';
import { isDue, fmtDate, initials, avColor, toast, showModal, closeModal } from '../lib/utils.js';
import { insertClient, updateClient, deleteClient } from '../lib/data.js';
import { iGlobe, iSearch, iPlus, iInfo } from '../lib/icons.js';

// ── Flow config ───────────────────────────────────────────────
const FLOWS = [
  {
    id: 'DIFM',
    label: 'DIFM',
    full: 'Do It For Me',
    desc: 'Agency builds websites for clients',
    benchmarkUrl: 'https://www.duda.co/solutions/agencies',
    color: 'badge-blue',
  },
  {
    id: 'DIWM',
    label: 'DIWM',
    full: 'Do It With Me',
    desc: 'Agency collaborates with clients on builds',
    benchmarkUrl: 'https://www.duda.co/solutions/agencies',
    color: 'badge-blue',
  },
  {
    id: 'DIY',
    label: 'DIY',
    full: 'Do It Yourself',
    desc: 'SaaS / platform — end users build themselves',
    benchmarkUrl: 'https://www.duda.co/solutions/saas-platforms',
    color: 'badge-green',
  },
];

export function getFlow(id) { return FLOWS.find(f => f.id === id) || null; }

function flowBadge(flow_id) {
  const f = getFlow(flow_id);
  if (!f) return '<span class="badge badge-gray">—</span>';
  return `<span class="badge ${f.color}" title="${f.full}">${f.label}</span>`;
}

function flowPickerHTML(selected = 'DIFM', prefix = 'fp') {
  return `
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px" id="${prefix}-grid">
    ${FLOWS.map(f => `
    <div class="role-opt ${f.id === selected ? 'sel' : ''}"
         id="${prefix}-${f.id}"
         data-action="setFlow" data-prefix="${prefix}" data-flow="${f.id}"
         style="cursor:pointer">
      <div class="role-opt-name" style="display:flex;align-items:center;gap:6px">
        <span class="badge ${f.color}" style="font-size:9px">${f.label}</span>
      </div>
      <div style="font-size:11px;font-weight:500;margin:3px 0 2px">${f.full}</div>
      <div class="role-opt-desc">${f.desc}</div>
    </div>`).join('')}
  </div>`;
}

// ── Clients list ──────────────────────────────────────────────
export function renderClients() {
  if (!state.clients.length) return `
    <div class="empty">
      <div class="empty-icon">${iGlobe}</div>
      <div class="empty-title">No clients yet</div>
      <div class="empty-sub">Add your first client site to start monitoring</div>
      <button class="btn btn-primary btn-sm" data-action="openAddClientModal">${iPlus} Add client</button>
    </div>`;

  return `<div class="card"><div class="tbl-wrap"><table>
    <thead><tr><th>Client</th><th>URL</th><th>Flow</th><th>AM owner</th><th>Last scan</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
      ${state.clients.map(client => {
        const am = state.members.find(m => m.id === client.am_id);
        const editable = canEditClient(client);
        return `<tr>
          <td>
            <div style="font-weight:600">${client.name}</div>
            ${client.notes ? `<div style="font-size:11px;color:var(--text3)">${client.notes}</div>` : ''}
          </td>
          <td><span class="mono" style="color:var(--brand)">${client.url.replace(/^https?:\/\//, '').slice(0, 30)}</span></td>
          <td>${flowBadge(client.client_flow)}</td>
          <td>
            ${am
              ? `<div style="display:flex;align-items:center;gap:7px">
                   <div class="av av-24 ${avColor(am.role)}">${initials(am.name)}</div>
                   <span style="font-size:11px">${am.name.split(' ')[0]}</span>
                 </div>`
              : '<span style="color:var(--text3);font-size:11px">Unassigned</span>'}
          </td>
          <td style="color:var(--text2);font-size:11px">${client.last_scan ? fmtDate(client.last_scan) : 'Never'}</td>
          <td>${isDue(client.last_scan)
            ? '<span class="badge badge-amber"><span class="dot"></span>Due</span>'
            : '<span class="badge badge-green"><span class="dot"></span>OK</span>'}</td>
          <td>
            <div style="display:flex;gap:5px;flex-wrap:wrap">
              <button class="btn btn-secondary btn-xs" data-action="runScan" data-id="${client.id}">${iSearch} Scan</button>
              ${editable ? `<button class="btn btn-ghost btn-xs" data-action="openEditClientModal" data-id="${client.id}">Edit</button>` : ''}
              ${editable
                ? `<button class="btn btn-danger btn-xs" data-action="deleteClient" data-id="${client.id}">Remove</button>`
                : '<span class="chip">View only</span>'}
            </div>
          </td>
        </tr>`;
      }).join('')}
    </tbody>
  </table></div></div>`;
}

// ── Add client modal ──────────────────────────────────────────
let _addFlow = 'DIFM';

export function openAddClientModal() {
  _addFlow = 'DIFM';
  const amOpts = state.members
    .filter(m => m.status === 'active')
    .map(m => `<option value="${m.id}" ${m.id === state.member.id ? 'selected' : ''}>${m.name}</option>`)
    .join('');

  showModal(`<div class="modal">
    <div class="modal-hd">
      <div class="modal-title">Add client site</div>
      <button class="modal-x" onclick="window._closeModal()">×</button>
    </div>
    <div class="modal-body">
      <div class="frow">
        <div class="fg"><label class="flabel">Client name *</label><input class="finput" id="ac-name" placeholder="Acme Digital Agency"></div>
        <div class="fg"><label class="flabel">Website URL *</label><input class="finput" id="ac-url" placeholder="https://www.client.com"></div>
      </div>
      <div class="fg">
        <label class="flabel">Client flow *</label>
        ${flowPickerHTML('DIFM', 'ac-fp')}
        <div class="fhint" id="ac-fp-hint" style="margin-top:8px">Benchmark: duda.co/solutions/agencies — AI will compare against this</div>
      </div>
      <div class="fg">
        <label class="flabel">Assign to AM</label>
        <select class="fselect" id="ac-am"><option value="">Unassigned</option>${amOpts}</select>
      </div>
      <div class="fg">
        <label class="flabel">Notes</label>
        <input class="finput" id="ac-notes" placeholder="e.g. SaaS platform, 5k+ end users">
        <div class="fhint">Context helps the AI tailor scan recommendations</div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-secondary" onclick="window._closeModal()">Cancel</button>
      <button class="btn btn-primary" id="ac-save-btn">Add client</button>
    </div>
  </div>`);

  document.getElementById('ac-save-btn').addEventListener('click', async () => {
    let name = document.getElementById('ac-name').value.trim();
    let url  = document.getElementById('ac-url').value.trim();
    const amId  = document.getElementById('ac-am').value || null;
    const notes = document.getElementById('ac-notes').value.trim();
    if (!name || !url) { toast('Name and URL are required', 'danger'); return; }
    if (!url.startsWith('http')) url = 'https://' + url;
    const { error } = await insertClient({ name, url, am_id: amId, notes, client_flow: _addFlow });
    if (error) { toast(error.message, 'danger'); return; }
    closeModal();
    window._reloadAndRender('clients');
    toast(`${name} added`, 'success');
  });
}

export function handleSetFlow(prefix, flowId) {
  if (prefix === 'ac-fp') {
    _addFlow = flowId;
    const f = getFlow(flowId);
    const hint = document.getElementById('ac-fp-hint');
    if (hint && f) hint.textContent = `Benchmark: ${f.benchmarkUrl.replace('https://www.', '')} — AI will compare against this`;
  } else if (prefix === 'ec-fp') {
    _editFlow = flowId;
    const f = getFlow(flowId);
    const hint = document.getElementById('ec-fp-hint');
    if (hint && f) hint.textContent = `Benchmark: ${f.benchmarkUrl.replace('https://www.', '')} — AI will compare against this`;
  }
  FLOWS.forEach(f => {
    const el = document.getElementById(`${prefix}-${f.id}`);
    if (el) el.classList.toggle('sel', f.id === flowId);
  });
}

// ── Edit client modal ─────────────────────────────────────────
let _editFlow = 'DIFM';

export function openEditClientModal(id) {
  const c = state.clients.find(x => x.id === id);
  if (!c) return;
  _editFlow = c.client_flow || 'DIFM';

  const amOpts = state.members
    .filter(m => m.status === 'active')
    .map(m => `<option value="${m.id}" ${c.am_id === m.id ? 'selected' : ''}>${m.name}</option>`)
    .join('');

  const f = getFlow(_editFlow);

  showModal(`<div class="modal">
    <div class="modal-hd">
      <div class="modal-title">Edit client</div>
      <button class="modal-x" onclick="window._closeModal()">×</button>
    </div>
    <div class="modal-body">
      <div class="frow">
        <div class="fg"><label class="flabel">Client name</label><input class="finput" id="ec-name" value="${c.name}"></div>
        <div class="fg"><label class="flabel">Website URL</label><input class="finput" id="ec-url" value="${c.url}"></div>
      </div>
      <div class="fg">
        <label class="flabel">Client flow</label>
        ${flowPickerHTML(_editFlow, 'ec-fp')}
        <div class="fhint" id="ec-fp-hint" style="margin-top:8px">Benchmark: ${f ? f.benchmarkUrl.replace('https://www.', '') : '—'} — AI will compare against this</div>
      </div>
      ${isAdmin() ? `<div class="fg"><label class="flabel">Assign to AM</label>
        <select class="fselect" id="ec-am"><option value="">Unassigned</option>${amOpts}</select>
      </div>` : ''}
      <div class="fg"><label class="flabel">Notes</label><input class="finput" id="ec-notes" value="${c.notes || ''}"></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-secondary" onclick="window._closeModal()">Cancel</button>
      <button class="btn btn-primary" id="ec-save-btn">Save</button>
    </div>
  </div>`);

  document.getElementById('ec-save-btn').addEventListener('click', async () => {
    const patch = {
      name:        document.getElementById('ec-name').value.trim() || c.name,
      url:         document.getElementById('ec-url').value.trim()  || c.url,
      notes:       document.getElementById('ec-notes').value.trim(),
      client_flow: _editFlow,
    };
    if (isAdmin()) patch.am_id = document.getElementById('ec-am').value || null;
    const { error } = await updateClient(id, patch);
    if (error) { toast(error.message, 'danger'); return; }
    closeModal();
    window._reloadAndRender('clients');
    toast('Client updated');
  });
}

export async function handleDeleteClient(id) {
  const c = state.clients.find(x => x.id === id);
  if (!confirm(`Remove ${c?.name} from monitoring?`)) return;
  await deleteClient(id);
  window._reloadAndRender('clients');
  toast('Client removed');
}
