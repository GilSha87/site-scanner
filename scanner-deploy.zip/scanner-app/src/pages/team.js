import { state, isAdmin } from '../lib/store.js';
import { fmtDate, initials, avColor, toast, showModal, closeModal, APP_DOMAIN, validateDudaEmail, pwStrength, togglePw } from '../lib/utils.js';
import { inviteMember, updateMember, suspendMember, reactivateMember, removeMember } from '../lib/data.js';
import { iLock, iInfo, iUsers, iPlus, iEye } from '../lib/icons.js';

export function renderTeam() {
  if (!isAdmin()) return `
    <div class="alert alert-info">${iLock}
      <span>Team management is restricted to Admins. Contact an Admin to make changes.</span>
    </div>`;

  const active    = state.members.filter(m => m.status === 'active');
  const suspended = state.members.filter(m => m.status === 'suspended');
  const admins    = active.filter(m => m.role === 'admin');

  return `
  <div class="stat-grid stat-grid-3" style="margin-bottom:18px">
    <div class="stat-card"><div class="stat-lbl">Active members</div><div class="stat-val">${active.length}</div></div>
    <div class="stat-card"><div class="stat-lbl">Admins</div><div class="stat-val">${admins.length}</div></div>
    <div class="stat-card"><div class="stat-lbl">Suspended</div>
      <div class="stat-val" style="color:${suspended.length > 0 ? 'var(--warn)' : 'inherit'}">${suspended.length}</div>
    </div>
  </div>

  <div class="alert alert-info" style="margin-bottom:18px">
    ${iLock}
    <span>Only <strong>@${APP_DOMAIN}</strong> email addresses are permitted. Enforced at database level — no external addresses can be invited.</span>
  </div>

  <div class="card" style="margin-bottom:16px">
    <div class="card-hd">
      <div class="card-title">${iUsers} Active members</div>
      <span class="badge badge-green"><span class="dot"></span>${active.length} active</span>
    </div>
    <div class="tbl-wrap"><table>
      <thead><tr><th>Member</th><th>Email</th><th>Role</th><th>Clients</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
        ${active.map(m => {
          const isMe       = m.id === state.member.id;
          const clientCount = state.clients.filter(c => c.am_id === m.id).length;
          return `<tr>
            <td>
              <div style="display:flex;align-items:center;gap:9px">
                <div class="av av-28 ${avColor(m.role)}">${initials(m.name)}</div>
                <div style="font-weight:600;font-size:12px">
                  ${m.name}${isMe ? ' <span class="badge badge-gray" style="font-size:9px">you</span>' : ''}
                </div>
              </div>
            </td>
            <td class="mono" style="color:var(--text2)">${m.email}</td>
            <td><span class="badge ${m.role === 'admin' ? 'badge-blue' : 'badge-green'}">${m.role}</span></td>
            <td style="color:var(--text2)">${clientCount} site${clientCount !== 1 ? 's' : ''}</td>
            <td style="font-size:11px;color:var(--text3)">${fmtDate(m.created_at)}</td>
            <td>
              <div style="display:flex;gap:4px;flex-wrap:wrap">
                <button class="btn btn-ghost btn-xs" data-action="openEditMemberModal" data-id="${m.id}">Edit</button>
                ${!isMe && m.role === 'staff' ? `<button class="btn btn-ghost btn-xs" data-action="changeRole" data-id="${m.id}" data-role="admin">Make admin</button>` : ''}
                ${!isMe && m.role === 'admin' && admins.length > 1 ? `<button class="btn btn-ghost btn-xs" data-action="changeRole" data-id="${m.id}" data-role="staff">Demote</button>` : ''}
                ${!isMe ? `<button class="btn btn-ghost btn-xs" data-action="suspendMember" data-id="${m.id}">Suspend</button>` : ''}
                ${!isMe ? `<button class="btn btn-danger btn-xs" data-action="removeMember" data-id="${m.id}">Delete</button>` : '<span class="chip">you</span>'}
              </div>
            </td>
          </tr>`;
        }).join('')}
      </tbody>
    </table></div>
  </div>

  ${suspended.length ? `
  <div class="card">
    <div class="card-hd">
      <div class="card-title">Suspended</div>
      <span class="badge badge-red">${suspended.length}</span>
    </div>
    <div class="tbl-wrap"><table>
      <thead><tr><th>Member</th><th>Email</th><th>Suspended</th><th>Actions</th></tr></thead>
      <tbody>
        ${suspended.map(m => `<tr>
          <td style="opacity:.6">
            <div style="display:flex;align-items:center;gap:9px">
              <div class="av av-28 av-amber">${initials(m.name)}</div>
              <div style="font-weight:600;font-size:12px">${m.name}</div>
            </div>
          </td>
          <td class="mono" style="color:var(--text2)">${m.email}</td>
          <td style="font-size:11px;color:var(--text3)">${fmtDate(m.updated_at || m.created_at)}</td>
          <td>
            <div style="display:flex;gap:5px">
              <button class="btn btn-success btn-xs" data-action="reactivateMember" data-id="${m.id}">Reactivate</button>
              <button class="btn btn-danger btn-xs" data-action="removeMember" data-id="${m.id}">Remove</button>
            </div>
          </td>
        </tr>`).join('')}
      </tbody>
    </table></div>
  </div>` : ''}`;
}

// ── Invite modal ──────────────────────────────────────────────
let _invRole = 'staff';

export function openInviteModal() {
  _invRole = 'staff';

  showModal(`<div class="modal">
    <div class="modal-hd">
      <div class="modal-title">Invite team member</div>
      <button class="modal-x" onclick="window._closeModal()">×</button>
    </div>
    <div class="modal-body">
      <div class="alert alert-info" style="margin-bottom:16px">
        ${iLock}
        <span>Only <strong>@${APP_DOMAIN}</strong> addresses accepted. Type the handle — domain is locked.</span>
      </div>
      <div class="fg">
        <label class="flabel">Full name *</label>
        <input class="finput" id="inv-name" placeholder="Sarah Chen">
      </div>
      <div class="fg">
        <label class="flabel">Work email *</label>
        <div class="domain-input-wrap">
          <input class="finput" id="inv-handle" placeholder="sarah.chen"
            oninput="document.getElementById('inv-preview').textContent = (this.value || 'handle') + '@${APP_DOMAIN}'">
          <div class="domain-suffix">${iLock} @${APP_DOMAIN}</div>
        </div>
        <div class="ferr" id="inv-err"></div>
        <div class="fhint">Preview: <strong id="inv-preview" style="font-family:var(--mono)">handle@${APP_DOMAIN}</strong></div>
      </div>
      <div class="fg">
        <label class="flabel">Initial password *</label>
        <div class="pw-wrap">
          <input class="finput" id="inv-pw" type="password" placeholder="Min 8 characters"
            oninput="window._pwStrength('inv-pw','inv-pw-bar')">
          <button class="pw-toggle" type="button" onclick="window._togglePw('inv-pw')">${iEye}</button>
        </div>
        <div class="pw-strength" id="inv-pw-bar"></div>
      </div>
      <div class="fg" style="margin-bottom:0">
        <label class="flabel">Role</label>
        <div class="role-grid">
          <div class="role-opt sel" id="inv-ropt-staff" data-action="setInvRole" data-role="staff">
            <div class="role-opt-name">Staff</div>
            <div class="role-opt-desc">Run scans, view all clients, edit own</div>
          </div>
          <div class="role-opt" id="inv-ropt-admin" data-action="setInvRole" data-role="admin">
            <div class="role-opt-name">Admin</div>
            <div class="role-opt-desc">Full control — team, clients, settings</div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-secondary" onclick="window._closeModal()">Cancel</button>
      <button class="btn btn-primary" id="inv-save-btn">Create account</button>
    </div>
  </div>`);

  document.getElementById('inv-save-btn').addEventListener('click', async () => {
    const name   = document.getElementById('inv-name').value.trim();
    const handle = (document.getElementById('inv-handle').value || '').trim().toLowerCase().replace(/[@\s]/g, '');
    const pw     = document.getElementById('inv-pw').value || '';
    const email  = handle ? `${handle}@${APP_DOMAIN}` : '';
    const errEl  = document.getElementById('inv-err');

    if (!name) { toast('Name is required', 'danger'); return; }
    const emailErr = validateDudaEmail(email);
    if (emailErr) { errEl.textContent = emailErr; errEl.classList.add('show'); return; }
    if (pw.length < 8) { toast('Password must be at least 8 characters', 'danger'); return; }
    errEl.classList.remove('show');

    const btn = document.getElementById('inv-save-btn');
    btn.disabled = true; btn.textContent = 'Creating…';

    const { error } = await inviteMember({ name, email, role: _invRole, password: pw });
    if (error) {
      btn.disabled = false; btn.textContent = 'Create account';
      errEl.textContent = error.message || 'Failed to create account';
      errEl.classList.add('show');
      return;
    }
    closeModal();
    window._reloadAndRender('team');
    toast(`${name} added as ${_invRole}`, 'success');
  });
}

export function setInviteRole(role) {
  _invRole = role;
  document.getElementById('inv-ropt-staff')?.classList.toggle('sel', role === 'staff');
  document.getElementById('inv-ropt-admin')?.classList.toggle('sel', role === 'admin');
}

// ── Edit member modal ─────────────────────────────────────────
let _editRole = 'staff';

export function openEditMemberModal(id) {
  const m = state.members.find(x => x.id === id);
  if (!m) return;
  _editRole = m.role;
  const isMe = m.id === state.member.id;

  showModal(`<div class="modal">
    <div class="modal-hd">
      <div class="modal-title">Edit member${isMe ? ' (you)' : ''}</div>
      <button class="modal-x" onclick="window._closeModal()">×</button>
    </div>
    <div class="modal-body">
      <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:var(--surface2);border-radius:var(--r);margin-bottom:16px">
        <div class="av av-28 ${avColor(m.role)}">${initials(m.name)}</div>
        <div>
          <div style="font-weight:600;font-size:13px">${m.name}</div>
          <div style="font-size:11px;color:var(--text2)">${m.email}</div>
        </div>
      </div>
      <div class="fg">
        <label class="flabel">Full name</label>
        <input class="finput" id="em-name" value="${m.name}">
      </div>
      ${!isMe ? `
      <div class="fg">
        <label class="flabel">Role</label>
        <div class="role-grid">
          <div class="role-opt ${m.role === 'staff' ? 'sel' : ''}" id="em-ropt-staff" data-action="setEditRole" data-role="staff">
            <div class="role-opt-name">Staff</div>
            <div class="role-opt-desc">Scanner access, edit own clients</div>
          </div>
          <div class="role-opt ${m.role === 'admin' ? 'sel' : ''}" id="em-ropt-admin" data-action="setEditRole" data-role="admin">
            <div class="role-opt-name">Admin</div>
            <div class="role-opt-desc">Full team and client control</div>
          </div>
        </div>
      </div>` : `
      <div class="alert alert-info" style="margin-bottom:14px">
        ${iInfo}<span>You're editing your own account. To change your password use the profile menu (bottom-left).</span>
      </div>`}
      <div class="fg" style="margin-bottom:0">
        <label class="flabel">Reset password <span style="font-weight:400;color:var(--text3)">(leave blank to keep current)</span></label>
        <div class="pw-wrap">
          <input class="finput" id="em-pw" type="password" placeholder="New password — min 8 characters"
            oninput="window._pwStrength('em-pw','em-pw-bar')">
          <button class="pw-toggle" type="button" onclick="window._togglePw('em-pw')">${iEye}</button>
        </div>
        <div class="pw-strength" id="em-pw-bar"></div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-secondary" onclick="window._closeModal()">Cancel</button>
      <button class="btn btn-primary" id="em-save-btn">Save changes</button>
    </div>
  </div>`);

  document.getElementById('em-save-btn').addEventListener('click', async () => {
    const name = document.getElementById('em-name').value.trim() || m.name;
    const pw   = document.getElementById('em-pw')?.value || '';
    const patch = { name, role: isMe ? m.role : _editRole };
    const { error } = await updateMember(id, patch);
    if (error) { toast(error.message, 'danger'); return; }
    // If editing self, also update state.member so sidebar reflects immediately
    if (isMe) { state.member = { ...state.member, name }; }
    closeModal();
    window._reloadAndRender('team');
    toast('Member updated');
  });
}

export function setEditRole(role) {
  _editRole = role;
  document.getElementById('em-ropt-staff')?.classList.toggle('sel', role === 'staff');
  document.getElementById('em-ropt-admin')?.classList.toggle('sel', role === 'admin');
}

// ── Member actions ────────────────────────────────────────────
export async function handleChangeRole(id, role) {
  const m = state.members.find(x => x.id === id);
  if (!confirm(`Change ${m?.name}'s role to ${role}?`)) return;
  await updateMember(id, { role });
  window._reloadAndRender('team');
  toast(`${m?.name} is now ${role}`);
}

export async function handleSuspendMember(id) {
  const m = state.members.find(x => x.id === id);
  if (!confirm(`Suspend ${m?.name}? They will lose access immediately.`)) return;
  await suspendMember(id);
  window._reloadAndRender('team');
  toast(`${m?.name} suspended`);
}

export async function handleReactivateMember(id) {
  await reactivateMember(id);
  window._reloadAndRender('team');
  const m = state.members.find(x => x.id === id);
  toast(`${m?.name} reactivated`);
}

export async function handleRemoveMember(id) {
  const m = state.members.find(x => x.id === id);
  if (!confirm(`Permanently remove ${m?.name}? This cannot be undone.`)) return;
  await removeMember(id);
  window._reloadAndRender('team');
  toast('Member removed');
}

// ── Role guide modal ──────────────────────────────────────────
export function openRoleGuide() {
  showModal(`<div class="modal">
    <div class="modal-hd">
      <div class="modal-title">Role permissions guide</div>
      <button class="modal-x" onclick="window._closeModal()">×</button>
    </div>
    <div class="modal-body">
      <table style="width:100%;font-size:12px;border-collapse:collapse">
        <thead>
          <tr>
            <th style="text-align:left;padding:8px 12px;background:var(--surface2);border-bottom:1px solid var(--border)">Permission</th>
            <th style="text-align:center;padding:8px 12px;background:var(--surface2);border-bottom:1px solid var(--border)">Staff</th>
            <th style="text-align:center;padding:8px 12px;background:var(--surface2);border-bottom:1px solid var(--border)">Admin</th>
          </tr>
        </thead>
        <tbody>
          ${[
            ['Run site scans',              '✓', '✓'],
            ['View all clients',            '✓', '✓'],
            ['Edit own assigned clients',   '✓', '✓'],
            ['Edit any client',             '—', '✓'],
            ['Invite team members',         '—', '✓'],
            ['Suspend / remove members',    '—', '✓'],
            ['Change member roles',         '—', '✓'],
            ['Access settings',             '—', '✓'],
            ['Export all data',             '—', '✓'],
          ].map(([p, s, a]) => `<tr>
            <td style="padding:8px 12px;border-bottom:1px solid var(--border)">${p}</td>
            <td style="text-align:center;padding:8px 12px;border-bottom:1px solid var(--border);color:${s === '✓' ? 'var(--success)' : 'var(--text3)'}">${s}</td>
            <td style="text-align:center;padding:8px 12px;border-bottom:1px solid var(--border);color:${a === '✓' ? 'var(--success)' : 'var(--text3)'}">${a}</td>
          </tr>`).join('')}
        </tbody>
      </table>
      <div class="alert alert-info" style="margin-top:14px">
        ${iLock}
        <span>All accounts must use <strong>@${APP_DOMAIN}</strong>. No external domains are permitted — enforced at the database level.</span>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-secondary" onclick="window._closeModal()">Close</button>
    </div>
  </div>`);
}
