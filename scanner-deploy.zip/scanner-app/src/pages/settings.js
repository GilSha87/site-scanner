import { state, isAdmin } from '../lib/store.js';
import { toast } from '../lib/utils.js';
import { clearScans } from '../lib/data.js';
import { IS_DEMO } from '../lib/data.js';
import { iLock, iCheck, iInfo } from '../lib/icons.js';

const EMAIL_ENABLED = import.meta.env.VITE_EMAIL_ENABLED === 'true';

export function renderSettings() {
  if (!isAdmin()) return `
    <div class="alert alert-info">${iLock}
      <span>Settings are restricted to Admins.</span>
    </div>`;

  return `
  <div style="max-width:580px">

    ${IS_DEMO ? `
    <div class="alert alert-warn" style="margin-bottom:20px">
      ${iInfo}
      <div>
        <strong>Demo mode — Supabase not connected</strong><br>
        <span style="font-size:11px;margin-top:2px;display:block">
          To connect a real database, add your Supabase keys to <code>.env</code> and restart the dev server.
          See <code>SETUP.md</code> for step-by-step instructions.
        </span>
      </div>
    </div>` : ''}

    <!-- Scan schedule -->
    <div class="card" style="margin-bottom:16px">
      <div class="card-hd"><div class="card-title">Scan schedule</div></div>
      <div class="card-body">
        <p style="font-size:12px;color:var(--text2);line-height:1.7;margin-bottom:12px">
          Sites are automatically queued for scanning when <code>last_scan</code> is older than 21 days.
          The scheduler runs daily at 07:00 UTC via <code>pg_cron</code>.
        </p>
        <div class="alert alert-success">
          ${iCheck}
          <span>pg_cron job <strong>queue-due-scans</strong> configured — queues overdue sites every morning at 07:00 UTC. Worker runs every 30 minutes.</span>
        </div>
      </div>
    </div>

    <!-- Email notifications -->
    <div class="card" style="margin-bottom:16px">
      <div class="card-hd">
        <div class="card-title">Email notifications</div>
        ${EMAIL_ENABLED
          ? '<span class="badge badge-green"><span class="dot"></span>Active</span>'
          : '<span class="badge badge-gray">Not configured</span>'}
      </div>
      <div class="card-body">
        ${EMAIL_ENABLED ? `
        <p style="font-size:12px;color:var(--text2);line-height:1.7;margin-bottom:12px">
          AMs receive a scan report email every time their assigned client site is scanned. Sent from <code>scanner@duda.co</code> via SendGrid.
        </p>
        <div class="alert alert-success">
          ${iCheck}
          <span>SendGrid active. Emails include changes, recommendations, and AM talking points.</span>
        </div>` : `
        <p style="font-size:12px;color:var(--text2);line-height:1.7;margin-bottom:12px">
          Email notifications are currently <strong>disabled</strong>. Scans still run and results are fully visible in the app.
          To enable, connect SendGrid and flip the flag in <code>.env</code>.
        </p>
        <div class="alert alert-warn">
          ${iInfo}
          <div>
            <strong>To enable emails:</strong>
            <ol style="padding-left:16px;margin-top:6px;font-size:11px;line-height:2">
              <li>Sign up at <strong>sendgrid.com</strong> and verify <code>duda.co</code> as a sender domain</li>
              <li>Run: <code>supabase secrets set SENDGRID_KEY=SG.your_key</code></li>
              <li>Set <code>VITE_EMAIL_ENABLED=true</code> in your <code>.env</code> file</li>
              <li>Restart the dev server — emails will send on the next scan</li>
            </ol>
          </div>
        </div>`}
      </div>
    </div>

    <!-- Anthropic API -->
    <div class="card" style="margin-bottom:16px">
      <div class="card-hd">
        <div class="card-title">AI scan engine</div>
        ${IS_DEMO
          ? '<span class="badge badge-amber">Demo mode</span>'
          : '<span class="badge badge-green"><span class="dot"></span>Connected</span>'}
      </div>
      <div class="card-body">
        ${IS_DEMO ? `
        <p style="font-size:12px;color:var(--text2);line-height:1.7;margin-bottom:12px">
          Running with demo scan results. To connect the real Anthropic API:
        </p>
        <div class="alert alert-warn">
          ${iInfo}
          <div>
            <strong>To enable real AI scans:</strong>
            <ol style="padding-left:16px;margin-top:6px;font-size:11px;line-height:2">
              <li>Connect Supabase (add keys to <code>.env</code>)</li>
              <li>Run: <code>supabase secrets set ANTHROPIC_KEY=sk-ant-...</code></li>
              <li>Deploy Edge Functions: <code>supabase functions deploy run-scan</code></li>
            </ol>
          </div>
        </div>` : `
        <div class="alert alert-success">
          ${iCheck}
          <span>Anthropic API connected. Scans use <strong>claude-sonnet-4-20250514</strong> with web search enabled.</span>
        </div>`}
      </div>
    </div>

    <!-- Data management -->
    <div class="card">
      <div class="card-hd"><div class="card-title">Data management</div></div>
      <div class="card-body">
        <div style="font-size:12px;color:var(--text2);margin-bottom:14px">
          ${state.scans.length} scans · ${state.clients.length} clients · ${state.members.length} members
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-secondary btn-sm" data-action="exportData">Export all data (JSON)</button>
          <button class="btn btn-danger btn-sm" data-action="clearScans">Clear scan history</button>
        </div>
      </div>
    </div>

  </div>`;
}

export async function handleClearScans() {
  if (!confirm('Clear all scan history? This cannot be undone.')) return;
  await clearScans();
  window._reloadAndRender('settings');
  toast('Scan history cleared');
}

export function handleExportData() {
  const blob = new Blob(
    [JSON.stringify({ members: state.members, clients: state.clients, scans: state.scans }, null, 2)],
    { type: 'application/json' }
  );
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `duda-scanner-export-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  toast('Export downloaded');
}
