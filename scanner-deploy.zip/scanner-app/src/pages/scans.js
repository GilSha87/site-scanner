import { state, isAdmin } from '../lib/store.js';
import { fmtDate, fmtTime, scoreColor, nextScanStr } from '../lib/utils.js';
import { iActivity, iSearch, iInfo, iCheck } from '../lib/icons.js';

const typeLabel = t => ({
  tier_shifting:'Tier shift', vertical_expansion:'New vertical',
  content_velocity:'Content growth', ai_adoption:'AI adoption',
  competitor_detected:'Competitor', page_404:'Page 404',
  lead_form_broken:'Form broken', ssl_expiry:'SSL expiry', duda_removed:'Duda removed'
}[t] || t);

const riskBadge = risk => risk === 'critical'
  ? '<span class="badge badge-red"><span class="dot"></span>Critical</span>'
  : risk === 'warn'
  ? '<span class="badge badge-amber"><span class="dot"></span>Warning</span>'
  : '<span class="badge badge-green"><span class="dot"></span>Clear</span>';

// ── Scan list ─────────────────────────────────────────────────
export function renderScans() {
  const myClients   = isAdmin() ? state.clients : state.clients.filter(c => c.am_id === state.member.id);
  const myClientIds = new Set(myClients.map(c => c.id));
  const scans = state.scans.filter(s => myClientIds.has(s.client_id));

  if (!scans.length) return `
    <div class="empty">
      <div class="empty-icon">${iActivity}</div>
      <div class="empty-title">No scan history yet</div>
      <div class="empty-sub">Run your first scan to see results here</div>
      <button class="btn btn-primary btn-sm" data-action="openScanPicker">Run scan</button>
    </div>`;

  return `<div class="card"><div class="tbl-wrap"><table>
    <thead><tr><th>Client</th><th>Scanned</th><th>Risk</th><th>Red flags</th><th>Growth signals</th><th>Score</th><th></th></tr></thead>
    <tbody>
      ${scans.map(scan => {
        const client = state.clients.find(c => c.id === scan.client_id);
        const risk   = scan.result?.riskLevel || 'ok';
        const flags  = scan.result?.redFlags?.length || 0;
        const growth = scan.result?.growthSignals?.length || 0;
        const sc     = scan.result?.score || '—';
        return `<tr>
          <td>
            <div style="font-weight:600">${client?.name || 'Unknown'}</div>
            <div class="mono" style="color:var(--text3)">${(client?.url || '').replace(/^https?:\/\//, '').slice(0, 28)}</div>
          </td>
          <td style="font-size:11px;color:var(--text2)">${fmtDate(scan.created_at)}<br>${fmtTime(scan.created_at)}</td>
          <td>${riskBadge(risk)}</td>
          <td>${flags > 0 ? `<span class="badge badge-red">${flags}</span>` : '<span class="badge badge-gray">0</span>'}</td>
          <td>${growth > 0 ? `<span class="badge badge-blue">${growth}</span>` : '<span class="badge badge-gray">0</span>'}</td>
          <td><strong style="color:${scoreColor(sc)}">${sc}/10</strong></td>
          <td><button class="btn btn-ghost btn-xs" data-action="viewScan" data-id="${scan.id}">View →</button></td>
        </tr>`;}).join('')}
    </tbody>
  </table></div></div>`;
}

// ── Full scan report ──────────────────────────────────────────
export function renderScanReport(scanId) {
  const scan   = state.scans.find(s => s.id === scanId);
  if (!scan) return '<div class="empty"><div class="empty-title">Scan not found</div></div>';

  const client = state.clients.find(c => c.id === scan.client_id);
  const am     = state.members.find(m => m.id === client?.am_id);
  const r      = scan.result || {};
  const sc     = r.score || '—';
  const risk   = r.riskLevel || 'ok';
  const EMAIL_ENABLED = (typeof import_meta_env !== 'undefined' ? import_meta_env : (window.__ENV__ || {})).VITE_EMAIL_ENABLED === 'true';

  const flow = client?.client_flow || r.client_flow || null;
  const flowMeta = { DIFM:{ label:'DIFM', full:'Do It For Me', color:'badge-blue' }, DIWM:{ label:'DIWM', full:'Do It With Me', color:'badge-blue' }, DIY:{ label:'DIY', full:'Do It Yourself', color:'badge-green' } };
  const fm = flowMeta[flow] || null;

  const severityBadge = sev => sev === 'critical'
    ? '<span class="badge badge-red">Critical</span>'
    : '<span class="badge badge-amber">Warning</span>';

  const growthTypeBadge = t => `<span style="font-size:9px;font-weight:700;background:var(--brand);color:#fff;padding:1px 6px;border-radius:10px;text-transform:uppercase;letter-spacing:.4px">${typeLabel(t)}</span>`;

  const dudaScoreColor = s => s >= 8 ? 'var(--success)' : s >= 5 ? 'var(--warn)' : 'var(--danger)';

  return `
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:18px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-xs" data-nav="scans">← Back to history</button>
    <span style="color:var(--text3)">|</span>
    <span style="font-weight:600">${client?.name || 'Unknown client'}</span>
    <span class="badge badge-gray">${fmtDate(scan.created_at)}, ${fmtTime(scan.created_at)}</span>
    ${riskBadge(risk)}
    ${fm ? `<span class="badge ${fm.color}" title="${fm.full}">${fm.label} — ${fm.full}</span>` : ''}
  </div>

  <div class="stat-grid stat-grid-4" style="margin-bottom:16px">
    <div class="stat-card"><div class="stat-lbl">Overall score</div><div class="stat-val" style="color:${scoreColor(sc)}">${sc}/10</div></div>
    <div class="stat-card"><div class="stat-lbl">Pages scanned</div><div class="stat-val" style="color:var(--brand)">${r.pagesScanned?.length || '—'}</div></div>
    <div class="stat-card"><div class="stat-lbl">Red flags</div><div class="stat-val" style="color:${r.redFlags?.length > 0 ? 'var(--danger)' : 'inherit'}">${r.redFlags?.length || 0}</div></div>
    <div class="stat-card"><div class="stat-lbl">Growth signals</div><div class="stat-val" style="color:${r.growthSignals?.length > 0 ? 'var(--brand)' : 'inherit'}">${r.growthSignals?.length || 0}</div></div>
  </div>

  ${r.pagesScanned?.length ? `
  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:14px;padding:9px 12px;background:var(--surface2);border-radius:var(--r);border:0.5px solid var(--border)">
    <span style="font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.5px">Pages scanned</span>
    ${r.pagesScanned.map(p => `<span class="chip">${p}</span>`).join('')}
  </div>` : ''}

  <div style="display:grid;grid-template-columns:1fr 350px;gap:16px;align-items:start">

    <!-- Left column -->
    <div>

      <!-- Executive summary -->
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd"><div class="card-title">Executive summary</div></div>
        <div class="card-body"><p style="line-height:1.7;color:var(--text2)">${r.summary || 'No summary available.'}</p></div>
      </div>

      <!-- Duda comparison -->
      ${r.dudaComparison ? `
      <div class="card" style="margin-bottom:14px;border-color:#BFDBFE">
        <div class="card-hd" style="background:#EFF6FF">
          <div class="card-title" style="color:#1D4ED8">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke-width="2"/><path d="M8 12l3 3 5-5" stroke-width="2"/></svg>
            Duda comparison
          </div>
          <a href="${r.dudaComparison.benchmarkUrl}" style="font-size:10px;color:var(--brand);font-family:var(--mono);text-decoration:none" target="_blank">${r.dudaComparison.benchmarkUrl.replace('https://www.','')}</a>
        </div>
        <div class="card-body">
          <p style="font-size:12px;color:var(--text2);line-height:1.7;margin-bottom:12px">${r.dudaComparison.summary}</p>
          ${r.dudaComparison.gaps?.length ? `
          <div style="margin-bottom:12px">
            <div style="font-size:10px;font-weight:700;color:var(--danger);text-transform:uppercase;letter-spacing:.5px;margin-bottom:7px">Gaps vs Duda</div>
            ${r.dudaComparison.gaps.map(g => `
            <div style="display:flex;gap:8px;margin-bottom:6px;font-size:12px;line-height:1.5">
              <span style="color:var(--danger);flex-shrink:0;font-weight:700">✗</span>${g}
            </div>`).join('')}
          </div>` : ''}
          ${r.dudaComparison.strengths?.length ? `
          <div>
            <div style="font-size:10px;font-weight:700;color:var(--success);text-transform:uppercase;letter-spacing:.5px;margin-bottom:7px">Strengths vs Duda</div>
            ${r.dudaComparison.strengths.map(s => `
            <div style="display:flex;gap:8px;margin-bottom:6px;font-size:12px;line-height:1.5">
              <span style="color:var(--success);flex-shrink:0;font-weight:700">✓</span>${s}
            </div>`).join('')}
          </div>` : ''}
        </div>
      </div>` : ''}

      <!-- Red flags -->
      ${r.redFlags?.length ? `
      <div class="card" style="margin-bottom:14px;border-color:var(--danger-border)">
        <div class="card-hd" style="background:var(--danger-bg)">
          <div class="card-title" style="color:var(--danger)">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke-width="2"/><line x1="12" y1="9" x2="12" y2="13" stroke-width="2"/><line x1="12" y1="17" x2="12.01" y2="17" stroke-width="3"/></svg>
            Red flags <span class="badge badge-red">${r.redFlags.length}</span>
          </div>
        </div>
        <div class="card-body" style="padding-top:12px">
          ${r.redFlags.map(f => `
          <div style="border:1px solid var(--danger-border);border-left:4px solid var(--danger);background:var(--danger-bg);border-radius:var(--r);padding:12px 14px;margin-bottom:10px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">
              ${severityBadge(f.severity)}
              <span style="font-size:9px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.5px">${typeLabel(f.type)}</span>
            </div>
            <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:4px">${f.title}</div>
            <div style="font-size:12px;color:var(--text2);line-height:1.5;margin-bottom:8px">${f.detail}</div>
            <div style="background:rgba(220,38,38,.08);border-radius:var(--r);padding:9px 12px">
              <div style="font-size:10px;font-weight:700;color:var(--danger);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">CSM Insight</div>
              <div style="font-size:12px;color:var(--text);line-height:1.5">${f.csmInsight}</div>
            </div>
          </div>`).join('')}
        </div>
      </div>` : `
      <div class="alert alert-success" style="margin-bottom:14px">
        ${iCheck}<span><strong>No red flags detected.</strong> Platform health looks good this cycle.</span>
      </div>`}

      <!-- Growth signals -->
      ${r.growthSignals?.length ? `
      <div class="card" style="margin-bottom:14px;border-color:var(--brand-mid)">
        <div class="card-hd" style="background:var(--brand-light)">
          <div class="card-title" style="color:var(--brand)">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18" stroke-width="2"/><polyline points="17 6 23 6 23 12" stroke-width="2"/></svg>
            Growth signals <span class="badge badge-blue">${r.growthSignals.length}</span>
          </div>
        </div>
        <div class="card-body" style="padding-top:12px">
          ${r.growthSignals.map(g => `
          <div style="border:1px solid var(--brand-mid);border-left:4px solid var(--brand);background:var(--brand-light);border-radius:var(--r);padding:12px 14px;margin-bottom:10px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">
              ${growthTypeBadge(g.type)}
            </div>
            <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:4px">${g.title}</div>
            <div style="font-size:12px;color:var(--text2);line-height:1.5;margin-bottom:8px">${g.detail}</div>
            <div style="background:rgba(29,78,216,.08);border-radius:var(--r);padding:9px 12px">
              <div style="font-size:10px;font-weight:700;color:var(--brand);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">CSM Action</div>
              <div style="font-size:12px;color:var(--text);line-height:1.5">${g.csmInsight}</div>
            </div>
          </div>`).join('')}
        </div>
      </div>` : ''}

      <!-- Detected changes -->
      ${r.changes?.length ? `
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd"><div class="card-title">Detected changes <span class="badge badge-amber">${r.changes.length}</span></div></div>
        <div class="card-body" style="padding-top:12px">
          ${r.changes.map(ch => `<div class="scan-item change"><div class="scan-tag">${ch.type}</div><div class="scan-name">${ch.title}</div><div class="scan-detail">${ch.detail}</div></div>`).join('')}
        </div>
      </div>` : ''}

      <!-- New content -->
      ${r.newContent?.length ? `
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd"><div class="card-title">New content <span class="badge badge-green">${r.newContent.length}</span></div></div>
        <div class="card-body" style="padding-top:12px">
          ${r.newContent.map(nc => `<div class="scan-item new-content"><div class="scan-tag">${nc.type}</div><div class="scan-name">${nc.title}</div><div class="scan-detail">${nc.detail}</div></div>`).join('')}
        </div>
      </div>` : ''}

      <!-- Per-page findings -->
      ${r.pageFindings?.length ? `
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd">
          <div class="card-title">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" stroke-width="2"/><polyline points="14 2 14 8 20 8" stroke-width="2"/></svg>
            Per-page findings
          </div>
          <span class="badge badge-gray">${r.pageFindings.length} pages</span>
        </div>
        <div class="card-body" style="padding:0">
          ${r.pageFindings.map((pf, idx) => `
          <div style="border-bottom:${idx < r.pageFindings.length-1 ? '0.5px solid var(--border)' : 'none'};padding:12px 14px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap">
              <span style="font-size:11px;font-weight:700;color:var(--text)">${pf.page}</span>
              <span class="mono" style="font-size:10px;color:var(--text3)">${pf.url}</span>
              <span class="badge ${pf.language === 'Outcome-focused' ? 'badge-green' : pf.language === 'Neutral' ? 'badge-gray' : 'badge-amber'}">${pf.language}</span>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:10px">
              <div style="background:var(--surface2);border-radius:var(--r);padding:7px 9px">
                <div style="font-size:9px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px">Headline</div>
                <div style="font-size:11px;color:var(--text)">${pf.headline}</div>
              </div>
              <div style="background:var(--surface2);border-radius:var(--r);padding:7px 9px">
                <div style="font-size:9px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px">CTA type</div>
                <div style="font-size:11px;color:var(--text)">${pf.ctaType}</div>
              </div>
              <div style="background:var(--surface2);border-radius:var(--r);padding:7px 9px">
                <div style="font-size:9px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px">CTA copy</div>
                <div style="font-size:11px;color:var(--text)">${pf.ctaText}</div>
              </div>
            </div>
            ${pf.findings?.length ? `
            <div style="margin-bottom:8px">
              ${pf.findings.map(f => `
              <div style="display:flex;gap:7px;margin-bottom:4px;font-size:11px;line-height:1.5">
                <span style="color:var(--warn);flex-shrink:0;font-weight:700;margin-top:1px">–</span>
                <span style="color:var(--text2)">${f}</span>
              </div>`).join('')}
            </div>` : ''}
            <div style="background:var(--brand-light);border-left:3px solid var(--brand);border-radius:0 var(--r) var(--r) 0;padding:7px 10px">
              <span style="font-size:9px;font-weight:700;color:var(--brand);text-transform:uppercase;letter-spacing:.5px">Suggestion  </span>
              <span style="font-size:11px;color:var(--text);line-height:1.5">${pf.suggestion}</span>
            </div>
          </div>`).join('')}
        </div>
      </div>` : ''}

      <!-- Recommendations -->
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd"><div class="card-title">Recommendations <span class="badge badge-blue">${r.improvements?.length || 0}</span></div></div>
        <div class="card-body" style="padding-top:12px">
          ${(r.improvements || []).map(imp => `
          <div class="scan-item improvement">
            <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">
              <div class="scan-tag">${imp.area}</div>
              <span class="badge ${imp.priority === 'high' ? 'badge-red' : imp.priority === 'medium' ? 'badge-amber' : 'badge-gray'}">${imp.priority}</span>
            </div>
            <div class="scan-name">${imp.title}</div>
            <div class="scan-detail">${imp.detail}</div>
          </div>`).join('')}
        </div>
      </div>

      <!-- Client-facing summary -->
      ${r.clientSummary ? `
      <div class="card">
        <div class="card-hd"><div class="card-title">Client-facing summary</div><span class="chip">Shareable</span></div>
        <div class="card-body">
          <div class="summary-card">
            <h3>${r.clientSummary.headline || (client?.name + ' Site Review')}</h3>
            <p>Reviewed ${fmtDate(scan.created_at)} · Duda Site Scanner</p>
            <div class="summary-meta">
              <div class="summary-meta-item"><span class="summary-meta-val">${sc}/10</span>Score</div>
              <div class="summary-meta-item"><span class="summary-meta-val">${r.redFlags?.length || 0}</span>Red flags</div>
              <div class="summary-meta-item"><span class="summary-meta-val">${r.growthSignals?.length || 0}</span>Growth signals</div>
            </div>
          </div>
          ${r.clientSummary.highlights?.length ? `
          <div style="margin-bottom:14px">
            <div style="font-size:10px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">What's working well</div>
            ${r.clientSummary.highlights.map(h => `<div style="display:flex;gap:8px;margin-bottom:6px;font-size:12px"><span style="color:var(--success);font-weight:700">✓</span>${h}</div>`).join('')}
          </div>` : ''}
          ${r.clientSummary.opportunities?.length ? `
          <div>
            <div style="font-size:10px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Quick wins</div>
            ${r.clientSummary.opportunities.map(o => `<div style="display:flex;gap:8px;margin-bottom:6px;font-size:12px"><span style="color:var(--brand);font-weight:700">→</span>${o}</div>`).join('')}
          </div>` : ''}
        </div>
      </div>` : ''}
    </div>

    <!-- Right column -->
    <div>

      <!-- Score breakdown -->
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd"><div class="card-title">Score breakdown</div></div>
        <div class="card-body">
          ${Object.entries(r.scoreBreakdown || {}).map(([k, v]) => {
            const labels = { services:'Services', pricing:'Pricing clarity', portfolio:'Portfolio', homepage:'Homepage', cta:'CTAs', trust:'Trust signals', ux:'UX', content:'Content', seo:'SEO', cro:'Conversion', mobile:'Mobile', performance:'Performance', discoverability:'Discoverability', pricing_clarity:'Pricing clarity', cta_strength:'CTA strength', offering_depth:'Offering depth', duda_alignment:'Duda alignment' };
            return `
          <div class="score-row">
            <div class="score-label-row">
              <span style="font-size:11px;font-weight:600">${labels[k] || k}</span>
              <span style="font-size:11px;font-weight:600">${v}/10</span>
            </div>
            <div class="score-bar"><div class="score-fill" style="width:${v*10}%;background:${scoreColor(v)}"></div></div>
          </div>`;}).join('')}
        </div>
      </div>

      <!-- Duda adoption -->
      ${r.dudaAdoption ? `
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd">
          <div class="card-title">Duda adoption</div>
          <span style="font-size:18px;font-weight:600;color:${dudaScoreColor(r.dudaAdoption.score)}">${r.dudaAdoption.score}/10</span>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
            <div style="background:var(--surface2);border-radius:var(--r);padding:9px 11px;text-align:center">
              <div style="font-size:18px;margin-bottom:2px">${r.dudaAdoption.flexUsed ? '✓' : '✗'}</div>
              <div style="font-size:10px;font-weight:600;color:${r.dudaAdoption.flexUsed ? 'var(--success)' : 'var(--danger)'}">Flex layout</div>
            </div>
            <div style="background:var(--surface2);border-radius:var(--r);padding:9px 11px;text-align:center">
              <div style="font-size:18px;margin-bottom:2px">${r.dudaAdoption.whitelabelIntact ? '✓' : '✗'}</div>
              <div style="font-size:10px;font-weight:600;color:${r.dudaAdoption.whitelabelIntact ? 'var(--success)' : 'var(--danger)'}">White-label intact</div>
            </div>
            <div style="background:var(--surface2);border-radius:var(--r);padding:9px 11px;text-align:center">
              <div style="font-size:18px;margin-bottom:2px">${!r.dudaAdoption.legacyWidgets ? '✓' : '✗'}</div>
              <div style="font-size:10px;font-weight:600;color:${!r.dudaAdoption.legacyWidgets ? 'var(--success)' : 'var(--warn)'}">No legacy widgets</div>
            </div>
            <div style="background:var(--surface2);border-radius:var(--r);padding:9px 11px;text-align:center">
              <div style="font-size:16px;font-weight:600;margin-bottom:2px">${r.dudaAdoption.widgetsDetected?.length || 0}</div>
              <div style="font-size:10px;font-weight:600;color:var(--text2)">Widgets active</div>
            </div>
          </div>
          ${r.dudaAdoption.widgetsDetected?.length ? `
          <div style="margin-bottom:10px">
            <div style="font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">Detected widgets</div>
            <div style="display:flex;flex-wrap:wrap;gap:4px">
              ${r.dudaAdoption.widgetsDetected.map(w => `<span class="chip">${w}</span>`).join('')}
            </div>
          </div>` : ''}
          <div style="background:var(--surface2);border-radius:var(--r);padding:10px 12px;font-size:11px;color:var(--text2);line-height:1.5">${r.dudaAdoption.insight}</div>
        </div>
      </div>` : ''}

      <!-- AM talking points -->
      ${r.talkingPoints?.length ? `
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd"><div class="card-title">AM talking points</div></div>
        <div class="card-body">
          <ul style="padding-left:16px;font-size:12px;line-height:1.7">
            ${r.talkingPoints.map(tp => `<li style="margin-bottom:8px">${tp}</li>`).join('')}
          </ul>
        </div>
      </div>` : ''}

      <!-- Email notification -->
      <div class="card">
        <div class="card-hd">
          <div class="card-title">Email notification</div>
          ${am ? '<span class="badge badge-green"><span class="dot"></span>Sent</span>' : '<span class="badge badge-gray">No AM assigned</span>'}
        </div>
        <div class="email-mock">
          <div class="email-hd">
            <div class="email-from">from: scanner@duda.co → ${am?.email || '(unassigned)'}</div>
            <div class="email-subj">Site report: ${client?.name} — ${fmtDate(scan.created_at)}</div>
          </div>
          <div class="email-body">
            <p>Hi ${(am?.name || state.member?.name || '').split(' ')[0] || 'there'},</p>
            <p style="margin:10px 0">${r.emailDigest || 'Your client site scan is complete.'}</p>
            ${r.redFlags?.length ? `
            <div class="email-section">
              <h4>⚠ Red flags (${r.redFlags.length})</h4>
              <ul>${r.redFlags.slice(0,3).map(f => `<li><strong>${f.title}</strong></li>`).join('')}</ul>
            </div>` : ''}
            ${r.growthSignals?.length ? `
            <div class="email-section">
              <h4>Growth signals (${r.growthSignals.length})</h4>
              <ul>${r.growthSignals.slice(0,2).map(g => `<li>${g.title}</li>`).join('')}</ul>
            </div>` : ''}
            <p style="margin-top:14px;font-size:11px;color:#9CA3AF">Duda Site Scanner · Next scan: ${nextScanStr(scan.created_at)}</p>
          </div>
        </div>
      </div>

    </div>
  </div>`;
}
