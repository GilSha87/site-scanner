import { signIn, getMemberByAuthId } from '../lib/data.js';
import { toast, APP_DOMAIN } from '../lib/utils.js';
import { iLock, iEye } from '../lib/icons.js';
import { state } from '../lib/store.js';
import { IS_DEMO } from '../lib/data.js';

export function renderLogin() {
  return `
  <div class="login-screen">
    <div class="login-card">
      <div class="login-eyebrow">Duda · Internal Tool</div>
      <div class="login-title">Site Scanner</div>
      <div class="login-sub">Strategic Account Manager portal</div>
      <div class="login-domain">${iLock}
        Restricted to <strong style="color:var(--text);margin:0 3px">@${APP_DOMAIN}</strong> accounts only
      </div>
      ${IS_DEMO ? `
      <div class="alert alert-warn" style="margin-bottom:16px">
        ${iLock}
        <span><strong>Demo mode</strong> — Supabase not connected. Use any @duda.co email + password <code>demo</code>.<br>
        <a href="https://github.com/your-org/duda-scanner#setup" style="color:var(--warn)">Connect Supabase →</a></span>
      </div>` : ''}
      <div class="fg">
        <label class="flabel">Work email</label>
        <input class="finput" id="l-email" type="email" placeholder="name@${APP_DOMAIN}" autocomplete="email">
        <div class="ferr" id="l-email-err"></div>
      </div>
      <div class="fg">
        <label class="flabel">Password ${IS_DEMO ? '<span style="color:var(--text3);font-weight:400">(type: demo)</span>' : ''}</label>
        <div class="pw-wrap">
          <input class="finput" id="l-pw" type="password" placeholder="••••••••" autocomplete="current-password">
          <button class="pw-toggle" type="button" onclick="document.getElementById('l-pw').type = document.getElementById('l-pw').type === 'password' ? 'text' : 'password'">${iEye}</button>
        </div>
        <div class="ferr" id="l-pw-err"></div>
      </div>
      <div class="ferr" id="l-gen-err" style="margin-bottom:10px"></div>
      <button class="btn btn-primary" style="width:100%;justify-content:center;padding:10px" id="l-btn">
        Sign in
      </button>
      <div style="margin-top:14px;text-align:center;font-size:11px;color:var(--text3)">
        No account? Contact your team Admin.
      </div>
    </div>
  </div>`;
}

export function attachLoginHandlers(onSuccess) {
  const btn = document.getElementById('l-btn');
  if (!btn) return;

  const doLogin = async () => {
    const email = (document.getElementById('l-email')?.value || '').trim().toLowerCase();
    const pw    = document.getElementById('l-pw')?.value || '';
    clearErrs();

    if (!email.endsWith('@' + APP_DOMAIN)) {
      showErr('email', `Only @${APP_DOMAIN} addresses allowed`); return;
    }
    if (!pw) { showErr('pw', 'Password is required'); return; }

    btn.disabled = true; btn.textContent = 'Signing in…';

    const { data, error } = await signIn(email, pw);
    if (error) {
      btn.disabled = false; btn.textContent = 'Sign in';
      showErr('gen', error.message || 'Sign in failed'); return;
    }

    // Load member row
    const member = await getMemberByAuthId(data.session.user.id);
    if (!member) { showErr('gen', 'Account not found. Contact your Admin.'); btn.disabled = false; btn.textContent = 'Sign in'; return; }
    if (member.status === 'suspended') { showErr('gen', 'Your account is suspended. Contact an Admin.'); btn.disabled = false; btn.textContent = 'Sign in'; return; }

    state.session = data.session;
    state.member  = member;
    onSuccess();
  };

  btn.addEventListener('click', doLogin);
  document.getElementById('l-pw')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
}

function clearErrs() {
  ['l-email-err', 'l-pw-err', 'l-gen-err'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.style.display = 'none'; el.classList.remove('show'); }
  });
  document.getElementById('l-email')?.classList.remove('err');
  document.getElementById('l-pw')?.classList.remove('err');
}

function showErr(field, msg) {
  if (field === 'gen') {
    const el = document.getElementById('l-gen-err');
    if (el) { el.textContent = msg; el.style.display = 'block'; el.classList.add('show'); }
    return;
  }
  const el = document.getElementById(`l-${field}-err`);
  if (el) { el.textContent = msg; el.classList.add('show'); }
  document.getElementById(`l-${field}`)?.classList.add('err');
}
